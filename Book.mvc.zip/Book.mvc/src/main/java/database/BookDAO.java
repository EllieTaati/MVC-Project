package database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.sql.PreparedStatement;
import models.Book;


public class BookDAO {
	
	
	Book oneBook = null;
	Connection conn = null;
    Statement stmt = null;
	String user = "shaldehe";
    String password = "jenKsrat9";
    String url = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/" + user;
   
	public BookDAO() {}

	//Open a connection to the database
	private void openConnection(){

		try {
			Class.forName("com.mysql.jdbc.Driver").getDeclaredConstructor().newInstance();
		} catch(Exception e) { System.out.println(e); }
		try{
			
			conn = DriverManager.getConnection(url, user, password);
		    stmt= conn.createStatement();
		} catch(SQLException se) { System.out.println(se); }	
    }
	
	//Close the connection to the database 
	private void closeConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}		
	//To get the next book from the result set
	private Book getNextBook(ResultSet rs){
    	Book thisBook=null;
		try {
			
			thisBook = new Book(
					rs.getInt("id"),
					rs.getString("title"),
					rs.getString("author"),
					rs.getString("date"),
					rs.getString("genres"),
					rs.getString("characters"),
					rs.getString("synopsis"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	return thisBook;		
	}
		
	//To get all books from the database
   	public ArrayList<Book> getAllBooks(){
		   
		ArrayList<Book> allBooks = new ArrayList<Book>();
		openConnection();
		
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from books";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneBook = getNextBook(rs1);
		    	allBooks.add(oneBook);
		   }
		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return allBooks;
   }
   //To get a book by its id 
   public Book getBookByID(int id){
	   
	   openConnection();
		oneBook=null;
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from books where id="+id;
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneBook = getNextBook(rs1);
		    }
		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }

	   return oneBook;
   }
   
   public Book getBookByTitle(String title ){
	   
	   openConnection();
		oneBook=null;
	    // Create select statement and execute it
		try{
		    String selectSQL = "select * from books where title='" + title + "'";
		    ResultSet rs1 = stmt.executeQuery(selectSQL);
	    // Retrieve the results
		    while(rs1.next()){
		    	oneBook = getNextBook(rs1);
		    }

		    stmt.close();
		    closeConnection();
		} catch(SQLException se) { System.out.println(se); }
	   return oneBook;
  }
   
   //To delete a book from database
   public void deleteBook(int id) {
	    try (Connection connection = DriverManager.getConnection(url, user, password);
	         PreparedStatement statement = (PreparedStatement) connection.prepareStatement("DELETE FROM books WHERE id = ?")) {
	        statement.setInt(1, id); // set the ID parameter
	        statement.executeUpdate(); // execute the delete statement
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
   }
  
   //To update a book in the database
   public void updateBook(Book b) {
	    String sql = "UPDATE books SET title=?, author=?, date=?,genres=?,characters=?, synopsis=? WHERE id=?";
	    System.out.println(b.getId());
	    try (Connection conn = DriverManager.getConnection(url, user, password);
	    		
	        PreparedStatement pstmt = conn.prepareStatement(sql)) {
	    	//Set the parameter values
	        pstmt.setString(1, b.getTitle());
	        pstmt.setString(2, b.getAuthor());
	        pstmt.setString(3, b.getDate());
	        pstmt.setString(4, b.getGenres());
	        pstmt.setString(5, b.getCharacters());
	        pstmt.setString(6, b.getSynopsis());
	        pstmt.setInt(7, b.getId());
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }	    
	    System.out.println(sql);
	    System.out.println(b.getId());
	}
   
   //To insert a book in the database
   public void insertBook(Book b) throws SQLException {
	    String sql = "INSERT INTO books (title, author, date, genres, characters, synopsis) VALUES (?, ?, ?, ?, ?, ?)";

	    try (Connection connection = DriverManager.getConnection(url, user, password);
	         PreparedStatement statement = (PreparedStatement) connection.prepareStatement(sql)) {
	    	
	    	//Set the parameter values for the prepared statement
	        statement.setString(1, b.getTitle());
	        statement.setString(2, b.getAuthor());
	        statement.setString(3, b.getDate());
	        statement.setString(4, b.getGenres());
	        statement.setString(5, b.getCharacters());
	        statement.setString(6, b.getSynopsis());

	        statement.executeUpdate();
	    }
	    System.out.println(sql);
   }

   
	//To search books based on a search string
   public Collection<Book> searchBook(String searchStr) {
        Collection<Book> books = new ArrayList<>();
        openConnection();

    try {
        String selectSQL = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR genres LIKE ? OR characters LIKE ?";
        PreparedStatement ps = conn.prepareStatement(selectSQL);
        
      //Set the search string as a wildcard parameter
        ps.setString(1, "%" + searchStr + "%");
        ps.setString(2, "%" + searchStr + "%");
        ps.setString(3, "%" + searchStr + "%");
        ps.setString(4, "%" + searchStr + "%");

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Book book = getNextBook(rs);
            books.add(book);
        }

        ps.close();
        closeConnection();
    } catch (SQLException se) {
        System.out.println(se);
    }
    return books;
}
}
   
  


