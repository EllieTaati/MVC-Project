package controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import database.BookDAO;
import models.Book;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
        int idParam = Integer.parseInt(request.getParameter("id"));//Get the book id from the request parameters
         
         BookDAO dao = new BookDAO();//Create an instance of BookDAO
         Book book = dao.getBookByID(idParam);//Get the book by its id from the database
         
         RequestDispatcher req = request.getRequestDispatcher("update.jsp");//Forward the request to the update.jsp page
         request.setAttribute("book", book);//Set the book as an attribute in the request
         request.getSession().setAttribute("id", idParam);//To store the book id in session as an attribute
         req.forward(request, response);
         
    }
  
    	 
    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
   
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	 //Get the book id from the session attribute
    	int idParam = Integer.parseInt(request.getParameter("id"));
    	    String title = request.getParameter("title");
    	    String author = request.getParameter("author");
    	    String date = request.getParameter("date");
    	    String genres = request.getParameter("genres");
    	    String characters = request.getParameter("characters");
    	    String synopsis = request.getParameter("synopsis");

    	    Book book = new Book(title, author, date, genres, characters, synopsis);//Create a new Book object with updated information
    	    book.setId(idParam);
    	    System.out.println(book);
    	    
    	    BookDAO dao = new BookDAO();
    	    
    	    try {
    	        dao.updateBook(book);
    	        System.out.println("Book Updated!");
    	        
    	        response.setContentType("text/html");//Set the response content type to HTML
	            PrintWriter out = response.getWriter();//Create a PrintWriter object to write the response
	          //To display an alert with a success message
	            out.println("<script>");
	            out.println("alert('Book updated successfully!');");
	            out.println("window.location.href='home';");
	            out.println("</script>");
	            
    	    } catch (Exception e) {
    	        e.printStackTrace();
    	        request.setAttribute("errorMsg", "An error occurred during the update process. Please try again.");
    	        request.getRequestDispatcher("error.jsp").forward(request, response);
    	    }
    	}
}
    	