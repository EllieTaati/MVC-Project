package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BookDAO;
import models.Book;

/**
 * Servlet implementation class InsertServlet
 */
@WebServlet("/InsertServlet")
public class InsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.sendRedirect("insert.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		    //Retrieve form data for a new book
		    String title = request.getParameter("title");
		    String author = request.getParameter("author");
		    String date = request.getParameter("date");
		    String genres = request.getParameter("genres");
		    String characters = request.getParameter("characters");
		    String synopsis = request.getParameter("synopsis");

		 // Perform validation
		    if (title.isEmpty() || author.isEmpty() || date.isEmpty() || genres.isEmpty() || characters.isEmpty() || synopsis.isEmpty()) {
		        // One or more required fields are empty
		    	    response.setContentType("text/html");
		    	    PrintWriter out = response.getWriter();
		    	    out.println("<script>");
		    	    out.println("alert('Please fill in all the required fields.');");
		    	    out.println("window.history.back();");
		    	    out.println("</script>");
		    	    return; // Stop further execution of the code
		    	
		    } else {
		        // All fields are filled, proceed with book insertion
		        Book book = new Book(title, author, date, genres, characters, synopsis);
		        System.out.println(book);

		        BookDAO bookDAO = new BookDAO();//Add the new book to database
		        try {
		            bookDAO.insertBook(book);
		            
		            response.setContentType("text/html");//Set the response content type to HTML
		            PrintWriter out = response.getWriter();//Create a PrintWriter object to write the response
		          //To display an alert with a success message
		            out.println("<script>");
		            out.println("alert('Book inserted successfully!');");
		            out.println("window.location.href='home';");
		            out.println("</script>");
		        } catch (SQLException e) {
		            // Book could not be inserted
		            e.printStackTrace();
		            request.setAttribute("errorMsg", "The new book could not be added. Please try again!");
		            request.getRequestDispatcher("error.jsp").forward(request, response);
		        }
		    }
		}
}
		   

