package controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BookDAO;

/**
 * Servlet implementation class DeleteServlet
 */
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private BookDAO bookDAO;
	
	public DeleteServlet() {
		
		super();// Call the constructor of the(HttpServlet)
		
		bookDAO = new BookDAO();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		    int id = Integer.parseInt(request.getParameter("id"));//Retrieve the book id from the request parameters
		    bookDAO.deleteBook(id);
		    
		    response.setContentType("text/html");//Set the response content type to HTML
		    PrintWriter out = response.getWriter();//Create a PrintWriter object to write the response 
		    //To display an alert with a success message
		    out.println("<script>");
		    out.println("alert('Book deleted successfully!');");
		    System.out.println("Book Deleted");
		    out.println("window.location.href='home';");
		    out.println("</script>");
		}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);//call the doGet method to process the request.
	}

}