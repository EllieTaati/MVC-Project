package controllers;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.BookDAO;
import models.Book;

/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/home")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
           
    public HomeServlet() {
        super();// Call the constructor of the(HttpServlet)      
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
	   BookDAO dao = new BookDAO();//Create an instance of BookDAO

		
	   ArrayList<Book> book = dao.getAllBooks();//Get all books from the database
       request.setAttribute("book", book);//Set the list of books as a request
       
       //Forward the request to the home.jsp
	   RequestDispatcher rq= request.getRequestDispatcher("home.jsp");
	   rq.include(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Retrieve form data for a new book
	    String title = request.getParameter("title");
	    String author = request.getParameter("author");
	    String date = request.getParameter("date");
	    String genres = request.getParameter("genres");
	    String characters = request.getParameter("characters");
	    String synopsis = request.getParameter("synopsis");
	    
	    Book book = new Book(title, author, date, genres, characters, synopsis);//Create a new Book object
	    BookDAO dao = new BookDAO();//Create an instance of BookDAO
	    
	    dao.updateBook(book);//Add the updated book to the database
	    response.sendRedirect("home");//To redirect the user back to the home page 
	}
}
